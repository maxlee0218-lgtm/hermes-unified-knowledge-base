# Automation Registry

## Repository

`maxlee0218-lgtm/warehouse-rebuild`

## Active automations

### 1. `Run warehouse-rebuild codex-ready issues every 15 minutes`

- type: Codex heartbeat automation
- role: periodic fallback scanner
- behavior:
  - scans open issues
  - enforces strict serial execution
  - skips when any issue is already `codex-running`

### 2. `Run warehouse-rebuild codex-ready issues every 5 minutes`

- type: Codex heartbeat automation
- role: higher-frequency idle scanner
- behavior:
  - scans only when idle
  - does not interrupt running work
  - same label state machine as the 15-minute automation

## Execution principles

- `codex-ready` means eligible to start
- `codex-running` means active and must not be interrupted
- `codex-done` means completed
- `codex-blocked` means blocked and awaiting follow-up

## Current rule

- Automations may coexist
- But actual task execution must remain strictly serial
- If any issue has `codex-running`, no new issue may start
